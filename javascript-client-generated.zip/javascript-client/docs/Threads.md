# SharioRestApi.Threads

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


