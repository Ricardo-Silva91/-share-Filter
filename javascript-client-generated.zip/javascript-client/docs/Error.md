# SharioRestApi.Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Number** |  | [optional] 
**message** | **String** |  | [optional] 
**fields** | **String** |  | [optional] 


