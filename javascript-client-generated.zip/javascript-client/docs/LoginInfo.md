# SharioRestApi.LoginInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user** | **String** |  | [optional] 
**pass** | **String** |  | [optional] 


