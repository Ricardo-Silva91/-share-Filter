# SharioRestApi.AddKeywordReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** |  | [optional] 
**keyword** | **String** |  | [optional] 


