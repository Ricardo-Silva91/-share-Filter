# SharioRestApi.LoginRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** |  | [optional] 
**result** | **String** |  | [optional] 


