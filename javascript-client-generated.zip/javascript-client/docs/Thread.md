# SharioRestApi.Thread

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**no** | **Number** |  | [optional] 
**com** | **String** |  | [optional] 
**filename** | **String** |  | [optional] 
**ext** | **String** |  | [optional] 
**pubDate** | **String** |  | [optional] 
**posts** | [**[Post]**](Post.md) |  | [optional] 


