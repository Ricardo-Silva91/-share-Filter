# SharioRestApi.OkRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **String** |  | [optional] 


